package Clients;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class UDPClient {

  private final static Logger LOGGER = Logger.getLogger(UDPClient.class.getName());

  public static String getCurrentTimeStamp() {
    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
  }

  //States if test passed or failed
  public static void completedTest(DatagramSocket serverSocket) throws IOException {
    byte[] buffer = new byte[64000];
    DatagramPacket receivedDatagramPacket = new DatagramPacket(buffer, 0, buffer.length);
    serverSocket.receive(receivedDatagramPacket);
    String message = new String(receivedDatagramPacket.getData());
    String[] testComplete = message.split(" ");

    if (testComplete[0].equals("Completed")) {
      System.out.println("passed");
    }else{
      System.out.println("failed");
    }
  }

  //Actually runs a test based on the inputted string
  public static void runTest(InetAddress IP, Integer port, DatagramSocket clientSocket, String str)
      throws IOException {


    DatagramPacket toSendDatagramPacket = new DatagramPacket(
        //turns the message into its bytes to be wrapped by the datagram
        str.getBytes(),
        //gets the messages proper length
        str.length(),
        //location of where message is coming from
        IP,
        //location of what port the message came from
        port
    );
     clientSocket.send(toSendDatagramPacket);
     completedTest(clientSocket);
  }

  //Runs the multiple tests prior to the program fully running
  public static void runTests(InetAddress IP, Integer port, DatagramSocket clientSocket) throws IOException {
    System.out.println("Testing...");
    runTest(IP, port, clientSocket, "put test1 1");
    runTest(IP, port, clientSocket, "put test2 2");
    runTest(IP, port, clientSocket, "put test3 3");
    runTest(IP, port, clientSocket, "put test4 4");
    runTest(IP, port, clientSocket, "put test5 5");
    runTest(IP, port, clientSocket, "get test1");
    runTest(IP, port, clientSocket, "get test2");
    runTest(IP, port, clientSocket, "get test3");
    runTest(IP, port, clientSocket, "get test4");
    runTest(IP, port, clientSocket, "get test5");
    runTest(IP, port, clientSocket, "delete test1");
    runTest(IP, port, clientSocket, "delete test2");
    runTest(IP, port, clientSocket, "delete test3");
    runTest(IP, port, clientSocket, "delete test4");
    runTest(IP, port, clientSocket, "delete test5");
    System.out.println("Testing done");

  }

  public static void main(String[] args) throws IOException {
    if (args.length < 2){
      System.out.println("NOT ENOUGH ARGS <IP> <PORT>");
    }
    String IP = args[0];
    Integer port = Integer.valueOf(args[1]);

    //creates the file handler that'll output the log and then format it properly
    FileHandler fileHandler = new FileHandler("UDPClient.log", true);
    LOGGER.addHandler(fileHandler);
    SimpleFormatter formatter = new SimpleFormatter();
    fileHandler.setFormatter(formatter);

    if (LOGGER.isLoggable(Level.INFO)) {
      LOGGER.info("Information message at " + getCurrentTimeStamp());
    }

    if (LOGGER.isLoggable(Level.WARNING)) {
      LOGGER.warning("Warning message at " +getCurrentTimeStamp());
    }

    LOGGER.log(Level.INFO, "Log started at " + getCurrentTimeStamp());



  try {
    Scanner scanner = new Scanner((System.in));
//    System.out.println("Enter IP and port number separated by a space: ");

//    //gets the IP and port values and parses them out
//    String IPPort = scanner.nextLine();
//    String[] IPPortList = IPPort.split(" ");
//    String IP = IPPortList[0];
//    Integer port = Integer.parseInt(IPPortList[1]);

    LOGGER.log(Level.INFO, "PREPARING DATAGRAM at " + getCurrentTimeStamp());
    DatagramSocket clientSocket = new DatagramSocket();
    byte[] buffer = new byte[65007];

   runTests(InetAddress.getByName(IP), port, clientSocket);
    while (true) {
      System.out.println("What's your request?: ");
      String message = scanner.nextLine();

      DatagramPacket toSendDatagramPacket = new DatagramPacket(
          //turns the message into its bytes to be wrapped by the datagram
          message.getBytes(),
          //gets the messages proper length
          message.length(),
          //location of where message is coming from
          InetAddress.getByName(IP),
          //location of what port the message came from
          port
      );

      LOGGER.log(Level.INFO, "Sending datagram packet at " + getCurrentTimeStamp());

      try {
        //sends the server a datagram packet
        clientSocket.send(toSendDatagramPacket);
        byte[] newBuffer = new byte[65007];

        //checks if the client takes too long
        clientSocket.setSoTimeout(6000);

        //setting up datagram packet to receive message from server
        DatagramPacket datagramPacket = new DatagramPacket(newBuffer, 0, buffer.length);
        clientSocket.receive(datagramPacket);

        String receivedMessage = new String(datagramPacket.getData());

        LOGGER.log(Level.INFO, "Received a datagram at " + getCurrentTimeStamp());
        System.out.println(receivedMessage);
      }
      catch (SocketTimeoutException e){
        LOGGER.log(Level.WARNING, "Socket timed out at " + getCurrentTimeStamp());
      }

    }


  } catch(SocketException e) {
    e.printStackTrace();
  } catch(IOException e){
    LOGGER.log(Level.WARNING, "TIME OUT OCCURED AT " + getCurrentTimeStamp());
    e.printStackTrace();
  }
}

}