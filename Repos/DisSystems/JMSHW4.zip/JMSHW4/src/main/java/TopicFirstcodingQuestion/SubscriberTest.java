package TopicFirstcodingQuestion;

import  static org.junit.Assert.assertEquals;
    import static org.junit.Assert.fail;

import javax.jms.JMSException;

    import org.junit.AfterClass;
    import org.junit.BeforeClass;
    import org.junit.Test;

public class SubscriberTest {

  private static MavenPublisher publisherSinglePublisher,
      publisherMultipleConsumers;
  private static DurableSubscriber subscriberPublishSubscribe,
      subscriber1MultipleConsumers, subscriber2MultipleConsumers,
      subscriber3FalseTimeMultipleConsumers;

  //creates the connections properly
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    publisherSinglePublisher = new MavenPublisher();
    publisherSinglePublisher.create("publisher-publishsubscribe",
        "publishsubscribe.t");

    publisherMultipleConsumers = new MavenPublisher();
    publisherMultipleConsumers.create("publisher-multipleconsumers",
        "multipleconsumers.t");

    subscriberPublishSubscribe = new DurableSubscriber();
    subscriberPublishSubscribe.create("subscriber-publishsubscribe",
        "publishsubscribe.t");

    subscriber1MultipleConsumers = new DurableSubscriber();
    subscriber1MultipleConsumers.create(
        "subscriber1-multipleconsumers", "multipleconsumers.t");

    subscriber2MultipleConsumers = new DurableSubscriber();
    subscriber2MultipleConsumers.create(
        "subscriber2-multipleconsumers", "multipleconsumers.t");

    subscriber3FalseTimeMultipleConsumers = new DurableSubscriber();
    subscriber3FalseTimeMultipleConsumers.create(
        "subscriber3-multipleconsumers", "multipleconsumers.t");
    subscriber3FalseTimeMultipleConsumers.setFlag(false);

  }

  //closes the connections
  @AfterClass
  public static void tearDownAfterClass() throws Exception {
    publisherSinglePublisher.closeConnection();
    publisherMultipleConsumers.closeConnection();


    subscriberPublishSubscribe.closeConnection();
    subscriber1MultipleConsumers.closeConnection();
    subscriber2MultipleConsumers.closeConnection();
    subscriber3FalseTimeMultipleConsumers.closeConnection();
  }

  @Test
  public void testGetGreeting() {
    //testing once one message is gotten by a subscriber it is not repeated
    try {
      publisherSinglePublisher.sendMessage("Bababooey");

      String greeting1 = subscriberPublishSubscribe.getGreeting(1000);
      assertEquals("Bababooey", greeting1);

      String greeting2 = subscriberPublishSubscribe.getGreeting(1000);
      assertEquals("no greeting", greeting2);

    } catch (JMSException e) {
      fail("a JMS Exception occurred");
    }
  }

  @Test
  public void testMultipleConsumers() {
    try {
      //sends the message to the Topic
      publisherMultipleConsumers.sendMessage("Oi Matey");

      //subscriber gets the consumer's message
      String greeting1 =
          subscriber1MultipleConsumers.getGreeting(1000);
      assertEquals("Oi Matey", greeting1);

      String greeting2 =
          subscriber2MultipleConsumers.getGreeting(1000);
      assertEquals("Oi Matey", greeting2);


      //checking if the
      String greeting3FalseTiming = subscriber3FalseTimeMultipleConsumers.getGreeting(1000);
      assertEquals("no greeting", greeting3FalseTiming);

      subscriber3FalseTimeMultipleConsumers.setFlag(true);
      String greeting4TrueTiming = subscriber3FalseTimeMultipleConsumers.getGreeting(1000);
      assertEquals("Oi Matey", greeting4TrueTiming);

    } catch (JMSException e) {
      fail("a JMS Exception occurred");
    }

  }

}