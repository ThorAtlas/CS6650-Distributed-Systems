import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * A ClientHandler class that'll handle clients requests one seperate threads
 */
public class ClientHandler implements Runnable{
  private Socket clientSocket;
  private BufferedReader in;
  private PrintWriter out;

  //method for clienthandler to use
  public static String reverseString(String var0) {
    StringBuilder var1 = new StringBuilder();
    var1.append(var0);
    var1.reverse();
    return var1.toString();
  }

  //Constructor for a clienthandler
  public ClientHandler(Socket clientSocket) throws IOException {
    this.clientSocket = clientSocket;
    in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
    out = new PrintWriter(clientSocket.getOutputStream(), true);
  }

  //the runner class to make the client handler run
  @Override
  public void run() {
    try {
      while (true){
        String input = in.readLine();
        if(input.equals("Q")){
          break;
        }
        String newString = reverseString(input);
        out.println(newString);
      }
    }
    catch (IOException e) {
      System.err.print("Exception occured in run handler");
      e.printStackTrace();
    }
    finally {
      out.close();
      try {
        in.close();
      } catch (IOException e) {
        e.printStackTrace();
      }

    }
  }
}
