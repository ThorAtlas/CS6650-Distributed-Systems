package RMIHW;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface SortRMI extends Remote {
  public List<Integer> sortList(List<Integer> a) throws RemoteException;
}
