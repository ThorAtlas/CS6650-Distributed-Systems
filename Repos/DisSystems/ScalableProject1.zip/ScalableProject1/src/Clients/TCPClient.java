package Clients;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class TCPClient {
  private final static Logger LOGGER = Logger.getLogger(TCPClient.class.getName());

  public static String getCurrentTimeStamp() {
    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
  }

  //States if test passed or failed
  public static void completedTest(BufferedReader bf) throws IOException {
    String str = bf.readLine();
    String[] testComplete = str.split(" ");
    if (testComplete[0].equals("Completed")) {
      System.out.println("passed");
    }else{
      System.out.println("failed");
    }
  }

  //Actually runs a test based on the inputted string
  public static void runTest(PrintWriter pr, BufferedReader bf, String str) throws IOException {
    pr.println(str);
    pr.flush();
    completedTest(bf);
  }

  //Runs the multiple tests prior to the program fully running
  public static void runTests(PrintWriter pr, BufferedReader bf) throws IOException {
    System.out.println("Testing...");
    runTest(pr, bf,"put test1 1");
    runTest(pr, bf,"put test2 2");
    runTest(pr, bf,"put test3 3");
    runTest(pr, bf,"put test4 4");
    runTest(pr, bf,"put test5 5");
    runTest(pr, bf, "get test1");
    runTest(pr, bf, "get test2");
    runTest(pr, bf, "get test3");
    runTest(pr, bf, "get test4");
    runTest(pr, bf, "get test5");
    runTest(pr, bf, "delete test1");
    runTest(pr, bf, "delete test2");
    runTest(pr, bf, "delete test3");
    runTest(pr, bf, "delete test4");
    runTest(pr, bf, "delete test5");
    System.out.println("Testing done");

  }
  public static void main(String[] args) throws IOException {
    if (args.length < 2){
      System.out.println("NOT ENOUGH ARGS <IP> <PORT>");
    }

    String IP = args[0];
    Integer port = Integer.valueOf(args[1]);

    //creates the file handler that'll output the log and then format it properly
    FileHandler fileHandler = new FileHandler("TCPClient.log", true);
    LOGGER.addHandler(fileHandler);
    SimpleFormatter formatter = new SimpleFormatter();
    fileHandler.setFormatter(formatter);

    if (LOGGER.isLoggable(Level.INFO)) {
      LOGGER.info("Information message");
    }

    if (LOGGER.isLoggable(Level.WARNING)) {
      LOGGER.warning("Warning message");
    }

    LOGGER.log(Level.INFO, "Log started at " + getCurrentTimeStamp());

    Scanner scanner = new Scanner((System.in));
//    System.out.println("Enter IP and port number separated by a space: ");

//    String IPPort = scanner.nextLine();
//    String[] IPPortList = IPPort.split(" ");
//    String IP = IPPortList[0];
//    Integer port = Integer.parseInt(IPPortList[1]);


    try {
      //where the information should go to
      // Socket s = new Socket("localhost", 1234);
      LOGGER.log(Level.INFO,"Attempting to connect to: " + IP + " at port: " + port + " at "
          + getCurrentTimeStamp());
      Socket s = new Socket(IP, port);
      PrintWriter pr = new PrintWriter(s.getOutputStream());
      InputStreamReader inputStreamReader = new InputStreamReader(s.getInputStream());
      BufferedReader bf = new BufferedReader(inputStreamReader);
      LOGGER.log(Level.INFO,"Sending IP address of client to server at " + getCurrentTimeStamp());
      pr.println(s.getInetAddress().toString());
      pr.flush();

      if(s.isConnected()){
        LOGGER.log(Level.INFO, "CONNECTED TO SERVER at " + getCurrentTimeStamp());
      }

      runTests(pr, bf);

      while(s.isConnected()) {

        System.out.print("What's your request? ");
        String textInput = scanner.nextLine();
        //creates something that can be sent out and sends it out

        LOGGER.log(Level.INFO, "Sending request to server at "+ getCurrentTimeStamp());

        pr.println(textInput);
        pr.flush();

        //reads the line buffered and prints it out
        String str = bf.readLine();
        System.out.println("client : " + str);
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

}

