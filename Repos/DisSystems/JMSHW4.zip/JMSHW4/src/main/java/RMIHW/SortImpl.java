package RMIHW;

import java.rmi.RemoteException;
import java.util.Collections;
import java.util.List;

public class SortImpl extends java.rmi.server.UnicastRemoteObject implements RMIHW.SortRMI{

  protected SortImpl() throws RemoteException {
    super();
  }

//  @Override
  public List<Integer> sortList(List<Integer> a) throws RemoteException {
    Collections.sort(a);
    System.out.println(a);
    return a;
  }

}
