package  Ignore;
import java.util.Scanner;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;

public class JMSQueueMessageSender
{
  //JMS URL
  private static String url = ActiveMQConnection.DEFAULT_BROKER_URL;
  //Queue name
  private static String queueName = "MESSAGE_QUEUE";

  //driver
  public static void main(String[] args) throws JMSException
  {
    // Getting JMS connection from the JMS server and starting it
    ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(url);
    Connection connection = connectionFactory.createConnection();
    connection.start();

    //Creates a new session to send/receives JMS messages and queue
    Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
    //creates the queue to send the message to
    Destination destination = session.createQueue(queueName);

    //Message producer sends the message to the queue
    MessageProducer producer = session.createProducer(destination);

    Scanner myObj = new Scanner(System.in);  // Create a Scanner object
    System.out.println("Enter message");
    String input = myObj.nextLine();
    TextMessage message = session.createTextMessage(input);

    //producer now sends the message
    producer.send(message);

    System.out.println("Message '" + message.getText() + ", Sent Successfully to the Queue");

    //closes
    connection.close();
  }
}