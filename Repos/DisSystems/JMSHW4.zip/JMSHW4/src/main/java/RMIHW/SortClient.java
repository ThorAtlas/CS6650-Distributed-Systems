package RMIHW;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SortClient {

  public static void main(String[] args){
    List<Integer> list = new ArrayList<>();
    Random rn = new Random();
    for (int i = 0; i<10; i++){
      list.add(rn.nextInt());
    }
    System.out.println("List prior to sort: " + list);
    try{
      Registry registry = LocateRegistry.getRegistry(6969);
      SortRMI sort = (SortRMI) registry.lookup("SortService");
      System.out.println(sort.sortList(list));
    }catch (Exception e){
      System.out.println("Not making it" + e);
    }
  }

}
