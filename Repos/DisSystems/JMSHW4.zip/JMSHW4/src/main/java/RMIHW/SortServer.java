package RMIHW;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class SortServer {

  public SortServer(){
    try{
      SortRMI s = new SortImpl();
      Registry register = LocateRegistry.createRegistry(6969);
      register.rebind("SortService", s);
    } catch (RemoteException e) {
      e.printStackTrace();
    }
  }

  public static void main(String args[]){
    new SortServer();
  }
}
