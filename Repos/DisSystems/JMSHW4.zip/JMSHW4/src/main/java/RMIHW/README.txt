README

The client will automatically generate 10 random integers and store them into a list
for you. It will print them out prior to sending it to the RMI server.
You can then see the return after the sort is completed.

1) Start Server
2) Start Client