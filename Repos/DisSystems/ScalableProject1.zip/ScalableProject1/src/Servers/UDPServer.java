package Servers;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class UDPServer  {

  static Map<String, String> keyPairMap = new HashMap<String, String>();

  private final static Logger LOGGER = Logger.getLogger(UDPServer.class.getName());

  /**
   * A function to sendpackets
   * @param message the message to be sent
   * @param clientIP the IP address of the client
   * @param clientPort the port of the client
   * @param serverSocket the socket to send out of
   * @throws IOException
   */
  public static void sendPacket(String message, InetAddress clientIP, Integer clientPort,
      DatagramSocket serverSocket) throws IOException {
    DatagramPacket toSendDatagramPacket = new DatagramPacket(
        //turns the message into its bytes to be wrapped by the datagram
        message.getBytes(),
        //gets the messages proper length
        message.length(),
        //location of where message is going to
        clientIP,
        //location of what port the message is to go to
        clientPort
    );
    serverSocket.send(toSendDatagramPacket);
    LOGGER.log(Level.INFO, "Sent a datagram at " + getCurrentTimeStamp());
  }

  public static String getCurrentTimeStamp() {
    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
  }

  /**
   * Handles the put action for the server. And sends a message to the client if it is completed
   *    * or not
   * @param splitString the list of command and key/pair
   * @param clientID the client's ID
   */
  public static void putHandler(String[] splitString, String clientID, InetAddress clientIP,
      Integer clientPort, DatagramSocket serverSocket) throws IOException {
    //checks if the client inputted the put method properly
    if(splitString.length > 2) {
      LOGGER.log(Level.INFO, clientID + " request: PUT" + splitString[1]
          + ":" + splitString[2]);

      //try block to actually put into the keypair hashmap
      try {
        //actually puts the pair into the hashmap

        keyPairMap.put(splitString[1], splitString[2]);
        //actually sends the statement to the client
        sendPacket("Completed request of adding key-pair",
            clientIP, clientPort, serverSocket);
        LOGGER.log(Level.INFO, "ADDED KEY-PAIR " + splitString[1] +":" +splitString[2]
            + getCurrentTimeStamp());
      }
      //catch block in case of any exceptions
      catch (Exception e) {
        sendPacket("Could not complete request of adding key-pair",
            clientIP, clientPort, serverSocket);
        LOGGER.log(Level.WARNING, "COULD NOT ADD KEY-PAIR at" + getCurrentTimeStamp());
      }
    }

    //if the client didn't input put properly then let the user know
    else{
      LOGGER.log(Level.WARNING, "Not enough input to put new keypair at" + getCurrentTimeStamp());
      sendPacket("Could not complete request of adding key-pair",
          clientIP, clientPort, serverSocket);
    }
  }

  /**
   * Handles the get action for the server. And sends a message to the client if it is completed
   *    * or not
   * @param splitString the list of command and key/pair
   * @param clientID the client's ID
   */
  public static void getHandler(String[] splitString, String clientID, InetAddress clientIP,
      Integer clientPort, DatagramSocket serverSocket) throws IOException {

    LOGGER.log(Level.INFO, clientID + " request: GET " + splitString[1] +" at" + getCurrentTimeStamp());
    try {
      //creates the message to be sent out in a packet and then ends it
      String wordToGet = keyPairMap.get(splitString[1]);
      StringBuilder newMessage = new StringBuilder();
      newMessage.append("Completed request of getting ").append(wordToGet);
      System.out.println(newMessage);
      sendPacket(newMessage.toString(), clientIP, clientPort, serverSocket);
      LOGGER.log(Level.INFO, "GOT VALUE " + wordToGet + " FROM KEY " + splitString[1]
          + " at " + getCurrentTimeStamp());

    }catch (Exception e){
      sendPacket("Could not complete request of getting key", clientIP, clientPort, serverSocket);
      LOGGER.log(Level.WARNING, "COULD NOT GET KEY at " + getCurrentTimeStamp());
    }
  }

  /**
   * Handles the delete action for the server. And sends a message to the client if it is completed
   * or not
   * @param splitString the list of command and key/pair
   * @param clientID the client's ID
   */
  public static void deleteHandler(String[] splitString, String clientID, InetAddress clientIP,
      Integer clientPort, DatagramSocket serverSocket) throws IOException {
    LOGGER.log(Level.INFO, clientID + " request: DELETE " + splitString[1] +" at " +getCurrentTimeStamp());

    try {
      //removes the keypair and tells the client it was successful
      String key = splitString[1];
      String value = keyPairMap.get(key);
      keyPairMap.remove(splitString[1]);
      sendPacket("Completed request delete", clientIP, clientPort, serverSocket);
      LOGGER.log(Level.INFO, "DELETED KEYPAIR " + key + ":" + value +" at "
          + getCurrentTimeStamp());


    }catch (Exception e){
      sendPacket("Could not complete request delete", clientIP, clientPort, serverSocket);
      LOGGER.log(Level.WARNING, "COULD NOT DELETE KEY at " +getCurrentTimeStamp());
    }
  }

  public static void main(String[] args) throws IOException {
    if (args.length < 1){
      System.out.println("ERROR, please enter one arguments <Port>");
      System.exit(1);
    }

    Integer IPPort = Integer.valueOf(args[0]);

    //creates the file handler that'll output the log and then format it properly
    FileHandler fileHandler = new FileHandler("UDPServer.log", true);
    LOGGER.addHandler(fileHandler);
    SimpleFormatter formatter = new SimpleFormatter();
    fileHandler.setFormatter(formatter);

    if (LOGGER.isLoggable(Level.INFO)) {
      LOGGER.info("Information message at " + getCurrentTimeStamp());
    }

    if (LOGGER.isLoggable(Level.WARNING)) {
      LOGGER.warning("Warning message at " +getCurrentTimeStamp());
    }

    LOGGER.log(Level.INFO, "Log started at " + getCurrentTimeStamp());

    try{
      LOGGER.log(Level.INFO, "Logging has started at" +getCurrentTimeStamp());
      //sets the port value of the server
//      Scanner scanner = new Scanner((System.in));
//      System.out.println("Port number you wish for the system to have: ");
//      Integer IPPort = Integer.valueOf(scanner.nextLine());

      //sets the server's Socket to the input
      DatagramSocket serverSocket = new DatagramSocket(IPPort);

      //creates a buffer for the datagrams
      byte[] buffer = new byte[65007];

      //continual loop that looks for input continuously
      while(true){

        //creates a datagrampacket for a received datagram and then receives it from the server
        DatagramPacket receivedDatagramPacket = new DatagramPacket(buffer, buffer.length);
        serverSocket.receive(receivedDatagramPacket);

        //gets the client's IP and port from the datagram
        InetAddress clientIP = receivedDatagramPacket.getAddress();
        Integer clientPort = receivedDatagramPacket.getPort();

        //decodes the message from the datagram as well as the client's info
        String clientID = "Client: IP: " + clientIP + " Port: " + IPPort;
        String message = new String(receivedDatagramPacket.getData(), 0, receivedDatagramPacket.getLength());

        //seperates the client's info into information valubale to the server
        String[] splitString = message.split(" ");

        //Put handler
        if(splitString[0].equalsIgnoreCase("put")){
          putHandler(splitString,clientID, clientIP, clientPort, serverSocket);
        }

        //get handler
        else if(splitString[0].equalsIgnoreCase("get")){
          getHandler(splitString, clientID, clientIP, clientPort, serverSocket);

        }
        //delete handler
        else if(splitString[0].equalsIgnoreCase("delete")){
          deleteHandler(splitString,clientID, clientIP, clientPort, serverSocket);

          //if it does not match the above methods then we send an error tot he user
        }else {
          LOGGER.log(Level.INFO, clientID + " request is invalid at " +getCurrentTimeStamp());
          sendPacket("Invalid request try something else",
              clientIP, clientPort, serverSocket);;

        }


      }

    }catch(SocketException | UnknownHostException e)

    {
      e.printStackTrace();
    } catch(
        IOException e)

    {
      e.printStackTrace();
    }
  }
}



