package Servers;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class TCPServer {


  //initializes the hashmap for the key-pair map
  static HashMap<String, String> keyPairMap = new HashMap();

  //creates a logger
  private final static Logger LOGGER = Logger.getLogger(TCPServer.class.getName());

  public static String getCurrentTimeStamp() {
    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date());
  }

  /**
   * Handles the put action for the server. And sends a message to the client if it is completed
   *    * or not
   * @param splitString the list of command and key/pair
   * @param pr the printwriter to be printed and flushed
   * @param clientID the client's ID
   */
  public static void putHandler(String[] splitString, PrintWriter pr, String clientID){
    //checks if the client inputted the put method properly
    if(splitString.length > 2) {
      LOGGER.log(Level.INFO, clientID + " request: PUT" + splitString[1]
          + ":" + splitString[2]);

      //try block to actually put into the keypair hashmap
      try {
        //actually puts the pair into the hashmap
        keyPairMap.put(splitString[1], splitString[2]);
        //actually sends the statement to the client
        pr.println("Completed request of adding key-pair at " + getCurrentTimeStamp());
        pr.flush();
        LOGGER.log(Level.INFO, "ADDED KEY-PAIR at " + getCurrentTimeStamp());
      }
      //catch block in case of any exceptions
      catch (Exception e) {
        pr.println("Could not complete request of adding key-pair at "
            + getCurrentTimeStamp());
        pr.flush();
        LOGGER.log(Level.WARNING, "COULD NOT ADD KEY-PAIR at " + getCurrentTimeStamp());
      }
    }

    //if the client didn't input put properly then let the user know
    else{
      LOGGER.log(Level.WARNING, "Not enough input to put new keypair at " + getCurrentTimeStamp());
      pr.println("Could not complete request of adding key-pair at "
          + getCurrentTimeStamp());
      pr.flush();
    }
  }

  /**
   * Handles the get action for the server. And sends a message to the client if it is completed
   *    * or not
   * @param splitString the list of command and key/pair
   * @param pr the printwriter to be printed and flushed
   * @param clientID the client's ID
   */
  public static void getHandler(String[] splitString, PrintWriter pr, String clientID){
    LOGGER.log(Level.INFO, clientID + " request: GET " + splitString[1] + " at " + getCurrentTimeStamp());

    try {
      String wordToGet = keyPairMap.get(splitString[1]);
      pr.println("Completed request of getting " + wordToGet
          + " at " + getCurrentTimeStamp());
      pr.flush();
      LOGGER.log(Level.INFO, "GOT VALUE FROM KEY at" +getCurrentTimeStamp());
    }catch (Exception e){
      pr.println("Could not complete request of getting key at "
          + getCurrentTimeStamp());
      pr.flush();
      LOGGER.log(Level.WARNING, "COULD NOT GET KEY at " +getCurrentTimeStamp());
    }
  }

  /**
   * Handles the delete action for the server. And sends a message to the client if it is completed
   * or not
   * @param splitString the list of command and key/pair
   * @param pr the printwriter to be printed and flushed
   * @param clientID the client's ID
   */
  public static void deleteHandler(String[] splitString, PrintWriter pr, String clientID){
    LOGGER.log(Level.INFO, clientID + " request: DELETE " + splitString[1]
        + " at " + getCurrentTimeStamp());
    try {
      keyPairMap.remove(splitString[1]);
      pr.println("Completed request delete"
          + " at " + getCurrentTimeStamp());
      pr.flush();
      LOGGER.log(Level.INFO, "DELETED KEYPAIR at " + getCurrentTimeStamp());
    }catch (Exception e){
      pr.println("Could not complete request of deleting key at "
          + getCurrentTimeStamp());
      pr.flush();
      LOGGER.log(Level.WARNING, "COULD NOT DELTE KEY at" +getCurrentTimeStamp());
    }
  }

  public static void main(String[] args) throws IOException {
    // initiate the tests for the hashmap proper function
    if(args.length <1){
      System.out.println("ERROR, please enter one argument <PORT>");
      System.exit(1);
    }

    Integer IPPort = Integer.valueOf(args[0]);

    //creates the file handler that'll output the log and then format it properly
    FileHandler fileHandler = new FileHandler("TCPServer.log", true);
    LOGGER.addHandler(fileHandler);
    SimpleFormatter formatter = new SimpleFormatter();
    fileHandler.setFormatter(formatter);


    if (LOGGER.isLoggable(Level.INFO)) {
      LOGGER.info("Information message");
    }

    if (LOGGER.isLoggable(Level.WARNING)) {
      LOGGER.warning("Warning message");
    }

    try {
      LOGGER.log(Level.INFO, "Logging has started at " + getCurrentTimeStamp());
      //sets up the port value
//      Scanner scanner = new Scanner(System.in);
//      System.out.println("Enter the socket value you wish the port to be: ");
//      Integer IPPort = Integer.valueOf(scanner.nextLine());

      //creation of the port/socket
      ServerSocket ss = new ServerSocket(IPPort);

      LOGGER.log(Level.INFO, "Port set to: " + IPPort + " at " + getCurrentTimeStamp());
      //server passively waits for a connection
      Socket s = ss.accept();

      //sets up input reader and a buffer for it alongside the printwriter for the client
      InputStreamReader in = new InputStreamReader(s.getInputStream());
      BufferedReader bf = new BufferedReader(in);
      PrintWriter pr = new PrintWriter(s.getOutputStream());

      //the next expected line from the client is its IP address
      String IPAddress = bf.readLine();

      //lets serverside know a client has connected
      LOGGER.log(Level.INFO,"Client connected from " + IPAddress + " at " + getCurrentTimeStamp());
      System.out.println("Client connected");

      String clientID = "Client: IP: " + IPAddress + " Port: " + IPPort;

      //while loop continues until the client leaves the socket/server
      while(s.isConnected()) {
        //gets what the client printed
        String str = bf.readLine();
        //splits it up into readable pieces
        String[] splitString = str.split(" ");

        //Put handler
        if(splitString[0].equalsIgnoreCase("put")){
          putHandler(splitString, pr, clientID);
        }

        //get handler
        else if(splitString[0].equalsIgnoreCase("get")){
          getHandler(splitString, pr, clientID);

        }
        //delete handler
        else if(splitString[0].equalsIgnoreCase("delete")){
          deleteHandler(splitString, pr, clientID);

          //if it does not match the above methods then we send an error tot he user
        }else {
          LOGGER.log(Level.INFO, clientID + " request is invalid at "
              + getCurrentTimeStamp());
          pr.println("Invalid request try something else at " + getCurrentTimeStamp());
          pr.flush();

        }
        pr.flush();

      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
